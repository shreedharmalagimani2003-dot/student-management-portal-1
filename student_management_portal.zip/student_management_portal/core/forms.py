from django import forms
from django.contrib.auth.models import User

from .models import Attendance, Marks, StudentProfile


class StudentRegistrationForm(forms.Form):
    """Used by an admin to create a new student account + profile in one step."""

    first_name = forms.CharField(max_length=150)
    last_name = forms.CharField(max_length=150, required=False)
    username = forms.CharField(max_length=150)
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
    roll_number = forms.CharField(max_length=20)
    course = forms.CharField(max_length=100)
    year_of_study = forms.IntegerField(min_value=1, max_value=6)
    phone_number = forms.CharField(max_length=15, required=False)

    def clean_username(self):
        username = self.cleaned_data["username"]
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("This username is already taken.")
        return username

    def clean_roll_number(self):
        roll_number = self.cleaned_data["roll_number"]
        if StudentProfile.objects.filter(roll_number=roll_number).exists():
            raise forms.ValidationError("A student with this roll number already exists.")
        return roll_number

    def save(self):
        data = self.cleaned_data
        user = User.objects.create_user(
            username=data["username"],
            email=data["email"],
            password=data["password"],
            first_name=data["first_name"],
            last_name=data["last_name"],
        )
        profile = StudentProfile.objects.create(
            user=user,
            role="student",
            roll_number=data["roll_number"],
            course=data["course"],
            year_of_study=data["year_of_study"],
            phone_number=data["phone_number"],
        )
        return profile


class StudentEditForm(forms.ModelForm):
    class Meta:
        model = StudentProfile
        fields = ["roll_number", "course", "year_of_study", "phone_number"]


class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ["student", "date", "status"]
        widgets = {"date": forms.DateInput(attrs={"type": "date"})}


class MarksForm(forms.ModelForm):
    class Meta:
        model = Marks
        fields = ["student", "subject", "exam_name", "marks_obtained", "max_marks"]
