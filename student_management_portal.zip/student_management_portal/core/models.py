from django.contrib.auth.models import User
from django.db import models


class StudentProfile(models.Model):
    """Extends Django's built-in User with student-specific fields and role."""

    ROLE_CHOICES = (
        ("admin", "Administrator"),
        ("student", "Student"),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default="student")
    roll_number = models.CharField(max_length=20, unique=True, blank=True, null=True)
    course = models.CharField(max_length=100, blank=True)
    year_of_study = models.PositiveSmallIntegerField(blank=True, null=True)
    phone_number = models.CharField(max_length=15, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def is_admin(self):
        return self.role == "admin"

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} ({self.role})"


class Attendance(models.Model):
    STATUS_CHOICES = (
        ("present", "Present"),
        ("absent", "Absent"),
    )

    student = models.ForeignKey(
        StudentProfile, on_delete=models.CASCADE, related_name="attendance_records"
    )
    date = models.DateField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="present")
    marked_by = models.ForeignKey(
        User, on_delete=models.SET_NULL, null=True, related_name="attendance_marked"
    )

    class Meta:
        unique_together = ("student", "date")
        ordering = ["-date"]

    def __str__(self):
        return f"{self.student} - {self.date} - {self.status}"


class Marks(models.Model):
    student = models.ForeignKey(
        StudentProfile, on_delete=models.CASCADE, related_name="marks_records"
    )
    subject = models.CharField(max_length=100)
    marks_obtained = models.DecimalField(max_digits=5, decimal_places=2)
    max_marks = models.DecimalField(max_digits=5, decimal_places=2, default=100)
    exam_name = models.CharField(max_length=100, default="Internal Assessment")
    date_recorded = models.DateField(auto_now_add=True)

    class Meta:
        ordering = ["-date_recorded"]

    def percentage(self):
        if self.max_marks:
            return round((self.marks_obtained / self.max_marks) * 100, 2)
        return 0

    def __str__(self):
        return f"{self.student} - {self.subject} - {self.marks_obtained}/{self.max_marks}"
