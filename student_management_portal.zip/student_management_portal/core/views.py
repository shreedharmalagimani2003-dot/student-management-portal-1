from django.contrib import messages
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth import authenticate
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from .forms import AttendanceForm, MarksForm, StudentEditForm, StudentRegistrationForm
from .models import Attendance, Marks, StudentProfile


def is_admin_user(user):
    return hasattr(user, "profile") and user.profile.is_admin()


def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect("dashboard")
        messages.error(request, "Invalid username or password.")

    return render(request, "core/login.html")


@login_required
def logout_view(request):
    auth_logout(request)
    return redirect("login")


@login_required
def dashboard(request):
    profile = request.user.profile

    if profile.is_admin():
        students = StudentProfile.objects.filter(role="student")
        context = {
            "profile": profile,
            "total_students": students.count(),
            "students": students[:10],
        }
        return render(request, "core/dashboard_admin.html", context)

    attendance_records = profile.attendance_records.all()[:10]
    marks_records = profile.marks_records.all()[:10]
    total_days = profile.attendance_records.count()
    present_days = profile.attendance_records.filter(status="present").count()
    attendance_percent = round((present_days / total_days) * 100, 1) if total_days else 0

    context = {
        "profile": profile,
        "attendance_records": attendance_records,
        "marks_records": marks_records,
        "attendance_percent": attendance_percent,
    }
    return render(request, "core/dashboard_student.html", context)


@login_required
def student_list(request):
    if not is_admin_user(request.user):
        messages.error(request, "You don't have permission to view this page.")
        return redirect("dashboard")

    students = StudentProfile.objects.filter(role="student").order_by("roll_number")
    return render(request, "core/student_list.html", {"students": students})


@login_required
def student_add(request):
    if not is_admin_user(request.user):
        messages.error(request, "You don't have permission to do that.")
        return redirect("dashboard")

    if request.method == "POST":
        form = StudentRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Student added successfully.")
            return redirect("student_list")
    else:
        form = StudentRegistrationForm()

    return render(request, "core/student_form.html", {"form": form, "mode": "Add"})


@login_required
def student_edit(request, pk):
    if not is_admin_user(request.user):
        messages.error(request, "You don't have permission to do that.")
        return redirect("dashboard")

    student = get_object_or_404(StudentProfile, pk=pk)
    if request.method == "POST":
        form = StudentEditForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, "Student details updated.")
            return redirect("student_list")
    else:
        form = StudentEditForm(instance=student)

    return render(request, "core/student_form.html", {"form": form, "mode": "Edit"})


@login_required
def student_delete(request, pk):
    if not is_admin_user(request.user):
        messages.error(request, "You don't have permission to do that.")
        return redirect("dashboard")

    student = get_object_or_404(StudentProfile, pk=pk)
    if request.method == "POST":
        student.user.delete()  # cascades to profile
        messages.success(request, "Student removed.")
        return redirect("student_list")

    return render(request, "core/student_confirm_delete.html", {"student": student})


@login_required
def attendance_mark(request):
    if not is_admin_user(request.user):
        messages.error(request, "You don't have permission to do that.")
        return redirect("dashboard")

    if request.method == "POST":
        form = AttendanceForm(request.POST)
        if form.is_valid():
            record = form.save(commit=False)
            record.marked_by = request.user
            record.save()
            messages.success(request, "Attendance recorded.")
            return redirect("attendance_mark")
    else:
        form = AttendanceForm()

    recent = Attendance.objects.select_related("student__user").all()[:20]
    return render(request, "core/attendance_form.html", {"form": form, "recent": recent})


@login_required
def marks_add(request):
    if not is_admin_user(request.user):
        messages.error(request, "You don't have permission to do that.")
        return redirect("dashboard")

    if request.method == "POST":
        form = MarksForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Marks recorded.")
            return redirect("marks_add")
    else:
        form = MarksForm()

    recent = Marks.objects.select_related("student__user").all()[:20]
    return render(request, "core/marks_form.html", {"form": form, "recent": recent})
