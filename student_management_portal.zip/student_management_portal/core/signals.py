from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import StudentProfile


@receiver(post_save, sender=User)
def create_admin_profile_for_superuser(sender, instance, created, **kwargs):
    """
    When a superuser is created via `createsuperuser`, automatically give
    them an admin StudentProfile so the role-based dashboard works for them
    without any extra manual step.
    """
    if created and instance.is_superuser and not hasattr(instance, "profile"):
        StudentProfile.objects.create(user=instance, role="admin")
