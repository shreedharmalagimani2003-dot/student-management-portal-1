from django.contrib import admin

from .models import Attendance, Marks, StudentProfile


@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ("roll_number", "user", "role", "course", "year_of_study")
    list_filter = ("role", "course", "year_of_study")
    search_fields = ("roll_number", "user__username", "user__first_name", "user__last_name")


@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ("student", "date", "status", "marked_by")
    list_filter = ("status", "date")


@admin.register(Marks)
class MarksAdmin(admin.ModelAdmin):
    list_display = ("student", "subject", "exam_name", "marks_obtained", "max_marks")
    list_filter = ("subject", "exam_name")
