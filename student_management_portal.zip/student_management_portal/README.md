# Student Management Portal

A full-stack web app for schools/colleges to manage students online — admins can
register students, mark attendance, and record marks instead of doing it on paper.
Students can log in to view their own attendance and marks.

## Tech Stack
- **Backend:** Python, Django
- **Frontend:** HTML, CSS (server-rendered Django templates)
- **Database:** SQLite by default (zero setup) — easily switched to MySQL

## Features
- Role-based login: Admin and Student accounts see different dashboards
- Admin can add, edit, and delete student records (CRUD)
- Admin can mark daily attendance and record exam marks per student
- Students can view their own attendance percentage and marks
- Clean, responsive UI with no external frontend framework needed

## Project Structure
```
student_management_portal/
├── config/              # Django project settings, URLs
├── core/                # Main app: models, views, forms, urls
├── templates/core/      # HTML templates
├── static/css/          # Stylesheet
├── manage.py
└── requirements.txt
```

## Setup & Run Locally

1. **Clone this repo and enter the folder**
   ```bash
   git clone <your-repo-url>
   cd student_management_portal
   ```

2. **Create a virtual environment and activate it**
   ```bash
   python -m venv venv
   # Windows:
   venv\Scripts\activate
   # Mac/Linux:
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run migrations** (creates the database tables)
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

5. **Create an admin account**
   ```bash
   python manage.py createsuperuser
   ```
   Follow the prompts. This account logs in as an Admin automatically.

6. **Run the development server**
   ```bash
   python manage.py runserver
   ```
   Open http://127.0.0.1:8000/ in your browser and log in with the superuser
   account you just created.

7. **Add students:** once logged in as admin, go to **Students → + Add Student**
   to create student logins. Those students can then log in and see their own
   dashboard.

## Switching to MySQL

By default this uses SQLite so it runs with zero extra setup. To match the
MySQL stack from the resume:

1. `pip install mysqlclient`
2. In `config/settings.py`, comment out the SQLite `DATABASES` block and
   uncomment the MySQL block just below it, filling in your MySQL credentials.
3. Create the database in MySQL: `CREATE DATABASE student_management_portal;`
4. Run `python manage.py migrate` again.

## Pushing to GitHub

```bash
git init
git add .
git commit -m "Initial commit: Student Management Portal"
git branch -M main
git remote add origin <the-URL-github-gives-you>
git push -u origin main
```
