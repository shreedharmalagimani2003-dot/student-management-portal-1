# Full-Stack Job Portal

A job-search platform with two types of users: **recruiters** who post job
openings, and **job seekers** who browse and apply. Recruiters can track every
application for their listings; seekers can see the status of jobs they've
applied to.

## Tech Stack
- **Backend:** Python, Django, Django REST Framework
- **Frontend:** HTML, CSS (server-rendered Django templates)
- **Database:** SQLite by default (zero setup) — easily switched to MySQL
- **REST API:** JSON endpoints for job listings (`/api/jobs/`)

## Features
- Two account types with separate dashboards: Recruiter and Job Seeker
- Recruiters can post jobs and view/manage applicants, updating each
  application's status (Applied → Reviewed → Shortlisted / Rejected)
- Job seekers can search jobs by title, apply with a cover note, and track
  their application status
- REST API endpoint (`/api/jobs/`) returns active job listings as JSON —
  demonstrates the backend API layer independent of the web pages
- Responsive, clean UI

## Project Structure
```
job_portal/
├── config/              # Django project settings, URLs
├── jobs/                # Main app: models, views, forms, API, urls
├── templates/jobs/      # HTML templates
├── static/css/          # Stylesheet
├── manage.py
└── requirements.txt
```

## Setup & Run Locally

1. **Clone this repo and enter the folder**
   ```bash
   git clone <your-repo-url>
   cd job_portal
   ```

2. **Create and activate a virtual environment**
   ```bash
   python -m venv venv
   # Windows:
   venv\Scripts\activate
   # Mac/Linux:
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run migrations**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

5. **Create an admin/recruiter account**
   ```bash
   python manage.py createsuperuser
   ```

6. **Run the server**
   ```bash
   python manage.py runserver
   ```
   Visit http://127.0.0.1:8000/ and log in with the superuser account
   (it's automatically set up as a Recruiter).

7. **Try it out:**
   - As the recruiter account: go to **+ Post a Job** to create a listing
   - Register a second account choosing **Job Seeker**, browse jobs, and apply
   - Switch back to the recruiter account to view and update that application's status

8. **Try the REST API:** visit http://127.0.0.1:8000/api/jobs/ while the
   server is running to see job listings as raw JSON.

## Switching to MySQL

1. `pip install mysqlclient`
2. In `config/settings.py`, comment out the SQLite block and uncomment the
   MySQL block, filling in your credentials.
3. `CREATE DATABASE job_portal;` in MySQL.
4. Run `python manage.py migrate` again.

## Pushing to GitHub

```bash
git init
git add .
git commit -m "Initial commit: Full-Stack Job Portal"
git branch -M main
git remote add origin <the-URL-github-gives-you>
git push -u origin main
```
