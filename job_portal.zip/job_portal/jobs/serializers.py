from rest_framework import serializers

from .models import Job


class JobSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(source="recruiter.company_name", read_only=True)

    class Meta:
        model = Job
        fields = [
            "id", "title", "company_name", "description", "location",
            "job_type", "salary_range", "skills_required", "is_active", "posted_at",
        ]
