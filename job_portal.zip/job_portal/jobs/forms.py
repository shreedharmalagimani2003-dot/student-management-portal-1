from django import forms
from django.contrib.auth.models import User

from .models import Application, Job, UserProfile


class RegisterForm(forms.Form):
    ROLE_CHOICES = (
        ("recruiter", "Recruiter — I want to post jobs"),
        ("seeker", "Job Seeker — I want to apply for jobs"),
    )

    first_name = forms.CharField(max_length=150)
    last_name = forms.CharField(max_length=150, required=False)
    username = forms.CharField(max_length=150)
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
    role = forms.ChoiceField(choices=ROLE_CHOICES, widget=forms.RadioSelect)
    company_name = forms.CharField(max_length=150, required=False)
    headline = forms.CharField(max_length=150, required=False)
    skills = forms.CharField(max_length=255, required=False)

    def clean_username(self):
        username = self.cleaned_data["username"]
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("This username is already taken.")
        return username

    def save(self):
        data = self.cleaned_data
        user = User.objects.create_user(
            username=data["username"],
            email=data["email"],
            password=data["password"],
            first_name=data["first_name"],
            last_name=data["last_name"],
        )
        profile = UserProfile.objects.create(
            user=user,
            role=data["role"],
            company_name=data.get("company_name", ""),
            headline=data.get("headline", ""),
            skills=data.get("skills", ""),
        )
        return profile


class JobForm(forms.ModelForm):
    class Meta:
        model = Job
        fields = [
            "title", "description", "location", "job_type",
            "salary_range", "skills_required", "is_active",
        ]
        widgets = {"description": forms.Textarea(attrs={"rows": 5})}


class ApplicationForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = ["cover_note"]
        widgets = {
            "cover_note": forms.Textarea(
                attrs={"rows": 4, "placeholder": "Why are you a good fit for this role? (optional)"}
            )
        }
