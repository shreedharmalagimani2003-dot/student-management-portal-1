from rest_framework import generics

from .models import Job
from .serializers import JobSerializer


class JobListAPIView(generics.ListAPIView):
    """
    GET /api/jobs/  -> JSON list of all active job postings.
    Public read-only endpoint, no auth required — used to demonstrate the
    project's REST API layer independent of the server-rendered pages.
    """
    queryset = Job.objects.filter(is_active=True)
    serializer_class = JobSerializer


class JobDetailAPIView(generics.RetrieveAPIView):
    """GET /api/jobs/<id>/ -> JSON detail for a single job posting."""
    queryset = Job.objects.all()
    serializer_class = JobSerializer
