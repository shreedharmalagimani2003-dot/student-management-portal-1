from django.contrib import admin

from .models import Application, Job, UserProfile


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "role", "company_name", "headline")
    list_filter = ("role",)


@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ("title", "recruiter", "location", "job_type", "is_active", "posted_at")
    list_filter = ("job_type", "is_active")
    search_fields = ("title", "location")


@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ("applicant", "job", "status", "applied_at")
    list_filter = ("status",)
