from django.urls import path

from . import api_views, views

urlpatterns = [
    path("", views.login_view, name="login"),
    path("register/", views.register_view, name="register"),
    path("logout/", views.logout_view, name="logout"),
    path("dashboard/", views.dashboard, name="dashboard"),

    path("jobs/", views.job_list, name="job_list"),
    path("jobs/post/", views.job_post, name="job_post"),
    path("jobs/<int:pk>/", views.job_detail, name="job_detail"),
    path("jobs/<int:pk>/apply/", views.job_apply, name="job_apply"),
    path("jobs/<int:pk>/applications/", views.job_applications, name="job_applications"),

    # REST API endpoints
    path("api/jobs/", api_views.JobListAPIView.as_view(), name="api_job_list"),
    path("api/jobs/<int:pk>/", api_views.JobDetailAPIView.as_view(), name="api_job_detail"),
]
