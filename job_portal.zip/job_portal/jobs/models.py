from django.contrib.auth.models import User
from django.db import models


class UserProfile(models.Model):
    ROLE_CHOICES = (
        ("recruiter", "Recruiter"),
        ("seeker", "Job Seeker"),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)

    # Recruiter-only fields
    company_name = models.CharField(max_length=150, blank=True)

    # Seeker-only fields
    headline = models.CharField(max_length=150, blank=True, help_text="e.g. 'Python Developer'")
    skills = models.CharField(max_length=255, blank=True, help_text="Comma-separated skills")

    def is_recruiter(self):
        return self.role == "recruiter"

    def __str__(self):
        return f"{self.user.username} ({self.role})"


class Job(models.Model):
    JOB_TYPE_CHOICES = (
        ("full_time", "Full-Time"),
        ("part_time", "Part-Time"),
        ("internship", "Internship"),
        ("remote", "Remote"),
    )

    recruiter = models.ForeignKey(
        UserProfile, on_delete=models.CASCADE, related_name="posted_jobs"
    )
    title = models.CharField(max_length=150)
    description = models.TextField()
    location = models.CharField(max_length=100)
    job_type = models.CharField(max_length=20, choices=JOB_TYPE_CHOICES, default="full_time")
    salary_range = models.CharField(max_length=50, blank=True)
    skills_required = models.CharField(max_length=255, blank=True)
    is_active = models.BooleanField(default=True)
    posted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-posted_at"]

    def __str__(self):
        return f"{self.title} @ {self.recruiter.company_name}"


class Application(models.Model):
    STATUS_CHOICES = (
        ("applied", "Applied"),
        ("reviewed", "Reviewed"),
        ("shortlisted", "Shortlisted"),
        ("rejected", "Rejected"),
    )

    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name="applications")
    applicant = models.ForeignKey(
        UserProfile, on_delete=models.CASCADE, related_name="applications"
    )
    cover_note = models.TextField(blank=True)
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default="applied")
    applied_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("job", "applicant")
        ordering = ["-applied_at"]

    def __str__(self):
        return f"{self.applicant.user.username} -> {self.job.title} ({self.status})"
