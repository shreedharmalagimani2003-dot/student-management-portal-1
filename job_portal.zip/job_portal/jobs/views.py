from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from .forms import ApplicationForm, JobForm, RegisterForm
from .models import Application, Job, UserProfile


def is_recruiter(user):
    return hasattr(user, "profile") and user.profile.is_recruiter()


def register_view(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            profile = form.save()
            auth_login(request, profile.user)
            messages.success(request, "Account created successfully.")
            return redirect("dashboard")
    else:
        form = RegisterForm()
    return render(request, "jobs/register.html", {"form": form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect("dashboard")

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect("dashboard")
        messages.error(request, "Invalid username or password.")

    return render(request, "jobs/login.html")


@login_required
def logout_view(request):
    auth_logout(request)
    return redirect("login")


@login_required
def dashboard(request):
    profile = request.user.profile

    if profile.is_recruiter():
        jobs = profile.posted_jobs.all()
        total_applications = Application.objects.filter(job__recruiter=profile).count()
        context = {
            "profile": profile,
            "jobs": jobs,
            "total_jobs": jobs.count(),
            "total_applications": total_applications,
        }
        return render(request, "jobs/dashboard_recruiter.html", context)

    my_applications = profile.applications.select_related("job").all()
    context = {"profile": profile, "my_applications": my_applications}
    return render(request, "jobs/dashboard_seeker.html", context)


@login_required
def job_list(request):
    jobs = Job.objects.filter(is_active=True)
    query = request.GET.get("q", "")
    if query:
        jobs = jobs.filter(title__icontains=query)
    return render(request, "jobs/job_list.html", {"jobs": jobs, "query": query})


@login_required
def job_detail(request, pk):
    job = get_object_or_404(Job, pk=pk)
    already_applied = False
    if not is_recruiter(request.user):
        already_applied = Application.objects.filter(
            job=job, applicant=request.user.profile
        ).exists()
    return render(
        request, "jobs/job_detail.html", {"job": job, "already_applied": already_applied}
    )


@login_required
def job_post(request):
    if not is_recruiter(request.user):
        messages.error(request, "Only recruiters can post jobs.")
        return redirect("dashboard")

    if request.method == "POST":
        form = JobForm(request.POST)
        if form.is_valid():
            job = form.save(commit=False)
            job.recruiter = request.user.profile
            job.save()
            messages.success(request, "Job posted successfully.")
            return redirect("dashboard")
    else:
        form = JobForm()

    return render(request, "jobs/job_form.html", {"form": form})


@login_required
def job_applications(request, pk):
    if not is_recruiter(request.user):
        messages.error(request, "You don't have permission to view this.")
        return redirect("dashboard")

    job = get_object_or_404(Job, pk=pk, recruiter=request.user.profile)

    if request.method == "POST":
        app_id = request.POST.get("application_id")
        new_status = request.POST.get("status")
        application = get_object_or_404(Application, pk=app_id, job=job)
        application.status = new_status
        application.save()
        messages.success(request, "Application status updated.")
        return redirect("job_applications", pk=job.pk)

    applications = job.applications.select_related("applicant__user").all()
    return render(
        request, "jobs/job_applications.html", {"job": job, "applications": applications}
    )


@login_required
def job_apply(request, pk):
    if is_recruiter(request.user):
        messages.error(request, "Recruiters cannot apply to jobs.")
        return redirect("dashboard")

    job = get_object_or_404(Job, pk=pk, is_active=True)
    profile = request.user.profile

    if Application.objects.filter(job=job, applicant=profile).exists():
        messages.info(request, "You've already applied to this job.")
        return redirect("job_detail", pk=pk)

    if request.method == "POST":
        form = ApplicationForm(request.POST)
        if form.is_valid():
            application = form.save(commit=False)
            application.job = job
            application.applicant = profile
            application.save()
            messages.success(request, "Application submitted.")
            return redirect("dashboard")
    else:
        form = ApplicationForm()

    return render(request, "jobs/job_apply.html", {"form": form, "job": job})
